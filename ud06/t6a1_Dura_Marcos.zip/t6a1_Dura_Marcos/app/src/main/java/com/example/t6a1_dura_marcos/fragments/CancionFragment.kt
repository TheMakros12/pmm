package com.example.t6a1_dura_marcos.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.t6a1_dura_marcos.R
import com.example.t6a1_dura_marcos.adapters.CancionAdapter
import com.example.t6a1_dura_marcos.adapters.CancionOnClickListener
import com.example.t6a1_dura_marcos.databinding.FragmentCancionBinding
import com.example.t6a1_dura_marcos.pojo.Cancion
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CancionFragment : Fragment(), CancionOnClickListener {

    private lateinit var binding: FragmentCancionBinding
    private lateinit var adapterCancion: CancionAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager
    private var listaCanciones: ArrayList<Cancion> = arrayListOf()
    private lateinit var itemDecoration: DividerItemDecoration

    companion object {

        private const val ARG_ALBUM_NOMBRE = "nombre_album"

        @JvmStatic
        fun newInstance(nombreAlbum: String): CancionFragment {
            val fragment = CancionFragment()
            var args = Bundle()
            args.putString(ARG_ALBUM_NOMBRE, nombreAlbum)
            fragment.arguments = args
            return fragment
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCancionBinding.inflate(inflater, container, false)

        linearLayoutManager = LinearLayoutManager(context);
        itemDecoration = DividerItemDecoration(context, DividerItemDecoration.VERTICAL)

        val nombreAlbum = arguments?.getString(ARG_ALBUM_NOMBRE) ?: ""

        listaCanciones = when (nombreAlbum) {
            "DeBÍ TiRAR MáS FOToS" -> Cancion.CancionDatos.DEBI_TIRAR_MAS_FOTOS
            "BUENAS NOCHES" -> Cancion.CancionDatos.BUENAS_NOCHES
            "TODOS LOS DÍAS TODO EL DÍA" -> Cancion.CancionDatos.TODOS_LOS_DIAS_TODO_EL_DIA
            "LUX" -> Cancion.CancionDatos.LUX
            "EN ESTA NOS FUIMOS LEJOS" -> Cancion.CancionDatos.EN_ESA_NOS_FUIMOS_LEJOS
            "SAYONARA" -> Cancion.CancionDatos.SAYONARA
            "Do Not Disturb" -> Cancion.CancionDatos.DO_NOT_DISTURB
            "Tranki, Todo Pasa" -> Cancion.CancionDatos.TRANKI_TODO_PASA
            "Some Sexy Songs 4U" -> Cancion.CancionDatos.SOME_SEXY_SONGS_4_U
            else -> arrayListOf()
        }

        adapterCancion = CancionAdapter(listaCanciones, this)

        binding.recyclerViewCancion.apply {
            adapter = adapterCancion
            layoutManager = linearLayoutManager
            addItemDecoration(itemDecoration)
        }

        return binding.root

    }

    override fun onClick(cancion: Cancion) {
        val mensaje = "Id: ${cancion.id}\nTítulo: ${cancion.titulo}\nDuración: ${cancion.duracion} min."

        // Creamos el AlertDialog
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Información de la canción")
            .setMessage(mensaje)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

}