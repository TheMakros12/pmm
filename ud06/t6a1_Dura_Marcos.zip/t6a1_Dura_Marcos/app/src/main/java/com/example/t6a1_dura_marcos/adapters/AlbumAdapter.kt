package com.example.t6a1_dura_marcos.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.t6a1_dura_marcos.R
import com.example.t6a1_dura_marcos.databinding.ItemAlbumBinding
import com.example.t6a1_dura_marcos.pojo.Album

class AlbumAdapter(private val albumes: List<Album>, private val listener: AlbumOnClickListener): RecyclerView.Adapter<AlbumAdapter.ViewHolder>() {

    private lateinit var context: Context

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        context = parent.context
        val view = LayoutInflater.from(context).inflate(R.layout.item_album, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val album = albumes[position]
        with(holder) {
            itemView.setOnClickListener {
                listener.onClick(album)
            }
            binding.tvNombreAlbum.text = album.titulo
            binding.tvArtistaAlbum.text = album.artista
            binding.tvAnyoAlbum.text = album.anyo.toString()
            Glide.with(context)
                .load(album.imagen)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(binding.cardViewImg)
        }
    }

    override fun getItemCount(): Int = albumes.size

    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val binding = ItemAlbumBinding.bind(view)
        fun setListener(album: Album) {
            binding.root.setOnClickListener {
                listener.onClick(album)
            }
        }

    }

}