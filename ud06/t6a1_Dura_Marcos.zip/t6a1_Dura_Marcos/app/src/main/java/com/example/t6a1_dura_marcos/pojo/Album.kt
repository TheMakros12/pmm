package com.example.t6a1_dura_marcos.pojo


data class Album(val titulo: String, val artista: String, val anyo: Int, val imagen: String) {

    class AlbumDatos {
        companion object {
            val ALBUMES = arrayListOf(
                Album("DeBÍ TiRAR MáS FOToS", "Bad Bunny", 2025, "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Album("BUENAS NOCHES", "Quevedo", 2024, "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Album("TODOS LOS DÍAS TODO EL DÍA", "Latin Mafia", 2024, "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Album("LUX", "ROSALíA", 2025, "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Album("EN ESTA NOS FUIMOS LEJOS", "Alejo", 2024, "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Album("SAYONARA", "Alvaro Díaz", 2023, "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Album("Do Not Disturb", "Young Miko", 2025, "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Album("Tranki, Todo Pasa", "Sech", 2024, "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Album("Some Sexy Songs 4U", "PARTYNEXTDOOR · Drake", 2025, "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59")
            )
        }
    }

}
