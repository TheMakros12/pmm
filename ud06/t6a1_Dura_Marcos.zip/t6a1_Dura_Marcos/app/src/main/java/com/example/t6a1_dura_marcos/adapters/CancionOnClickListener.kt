package com.example.t6a1_dura_marcos.adapters

import com.example.t6a1_dura_marcos.pojo.Cancion

interface CancionOnClickListener {
    fun onClick(cancion: Cancion)
}