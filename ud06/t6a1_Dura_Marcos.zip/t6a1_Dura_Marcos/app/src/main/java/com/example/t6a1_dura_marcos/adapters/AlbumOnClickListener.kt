package com.example.t6a1_dura_marcos.adapters

import com.example.t6a1_dura_marcos.pojo.Album

interface AlbumOnClickListener {
    fun onClick(album: Album)
}