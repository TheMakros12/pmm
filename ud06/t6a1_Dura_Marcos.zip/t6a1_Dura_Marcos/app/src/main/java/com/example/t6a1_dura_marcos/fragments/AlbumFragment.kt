package com.example.t6a1_dura_marcos.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.t6a1_dura_marcos.R
import com.example.t6a1_dura_marcos.activities.MainActivity
import com.example.t6a1_dura_marcos.adapters.AlbumAdapter
import com.example.t6a1_dura_marcos.adapters.AlbumOnClickListener
import com.example.t6a1_dura_marcos.databinding.FragmentAlbumBinding
import com.example.t6a1_dura_marcos.pojo.Album

class AlbumFragment : Fragment(), AlbumOnClickListener {

    private lateinit var adapterAlbum: AlbumAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var binding: FragmentAlbumBinding
    private lateinit var listener: AlbumOnClickListener

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAlbumBinding.inflate(inflater, container, false)

        adapterAlbum = AlbumAdapter(Album.AlbumDatos.ALBUMES, this)
        linearLayoutManager = LinearLayoutManager(context)
        binding.recyclerViewAlbum.apply {
            layoutManager = linearLayoutManager
            adapter = adapterAlbum
        }

        return binding.root
    }

    override fun onClick(album: Album) {

        val fragment = CancionFragment.newInstance(album.titulo)

        parentFragmentManager.beginTransaction()
            .replace(R.id.frangmentContainer, fragment)
            .addToBackStack(null)
            .commit()

    }

}