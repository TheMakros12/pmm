package com.example.t6a1_dura_marcos.activities

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.t6a1_dura_marcos.R
import com.example.t6a1_dura_marcos.databinding.ActivityMainBinding
import com.example.t6a1_dura_marcos.fragments.AlbumFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.frangmentContainer, AlbumFragment())
                .commit()
        }

    }

}