package com.example.t6a1_dura_marcos.pojo

class Cancion(val id: Int, val titulo: String, val duracion: String, val imagen: String) {

    class CancionDatos {
        companion object {
            val DEBI_TIRAR_MAS_FOTOS = arrayListOf(
                Cancion(1, "NUEVAYoL", "3:03", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(2, "VOY A LLeVARTE PA PR", "2:36", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(3, "BAILE INoLVIDABLE", "6:07", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(4, "PERFuMITO NUEVO", "3:20", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(5, "WELTiTA", "3:07", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(6, "VeLDÁ", "3:55", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(7, "EL ClúB", "3:42", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(8, "KETU TeCRÉ", "4:10", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(9, "BOKeTE", "3:35", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(10, "KLOuFRENS", "3:19", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(11, "TURiSTA", "3:10", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(12, "CAFé CON RON", "3:48", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(13, "PIToRRO DE COCO", "3:26", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(14, "LO QUE LE PASÓ A HAWAii", "3:49", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(15, "EoO", "3:24", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(16, "DtMF", "3:57", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411"),
                Cancion(17, "LA MuDANZA", "3:33", "https://i.scdn.co/image/ab67616d0000b273bbd45c8d36e0e045ef640411")
            )

            val BUENAS_NOCHES = arrayListOf(
                Cancion(1, "Kassandra", "3:03", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(2, "Duro", "2:42", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(3, "Iguales", "3:03", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(4, "Gran Vía", "3:33", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(5, "Chapiadora.com", "3:17", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(6, "Por Atrás", "2:51", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(7, "14 Febreros", "2:52", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(8, "La 125", "3:14", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(9, "Halo", "3:01", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(10, "Mr. Moondial", "2:45", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(11, "Qué Asco De Todo", "3:10", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(12, "Noemú", "3:26", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(13, "Shibatto", "2:18", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(14, "Los Días Contados", "2:41", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(15, "El Estribillo", "2:41", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(16, "Amaneció", "4:15", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(17, "Te Fallé", "3:39", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e"),
                Cancion(18, "Buenas Noches", "3:58", "https://i.scdn.co/image/ab67616d0000b2734b690afba75a356fcdad526e")
            )

            val TODOS_LOS_DIAS_TODO_EL_DIA = arrayListOf(
                Cancion(1, "Siento que merezco más", "2:46", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(2, "y como te digo que", "2:39", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(3, "nunca he sido honesto.", "2:55", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(4, "Me estoy cayendo", "2:51", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(5, "sentado aquí,", "2:44", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(6, "vivo si me exiges", "3:07", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(7, "pero me estoy acabando.", "2:47", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(8, "Qué vamos a hacer?", "2:13", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(9, "Yo siempre contesto.", "3:20", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(10, "Ven,", "2:27", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264"),
                Cancion(11, "tengo mucho ruido.", "3:22", "https://i.scdn.co/image/ab67616d0000b2735e92f2d649b34dbf56cf2264")
            )

            val LUX = arrayListOf(
                Cancion(1, "Sexo, Violencia y Llantas", "2:20", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(2, "Reliquia", "3:50", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(3, "Divinize", "4:03", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(4, "Porcelana", "4:08", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(5, "Mio Cristo Piange Diamanti", "4:29", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(6, "Berghain", "2:58", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(7, "La Perla", "3:15", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(8, "Mundo Nuevo", "2:20", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(9, "De Madrugá", "1:44", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(10, "Dios Es Un Stalker", "2:10", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(11, "La Yugular", "4:18", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(12, "Sauvignon Blanc", "2:42", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(13, "La Rumba Del Perdón", "4:11", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(14, "Memória", "3:45", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164"),
                Cancion(15, "Magnolias", "3:14", "https://i.scdn.co/image/ab67616d0000b27393ee2e2f2dfb7de9befcc164")
            )

            val EN_ESA_NOS_FUIMOS_LEJOS = arrayListOf(
                Cancion(1, "COSMO", "3:12", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(2, "LA CRUSH", "2:54", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(3, "CASA DE CAMPO", "3:22", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(4, "LOS LOBOS", "3:05", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(5, "COMO NICKY (NIKKI 2)", "3:18", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(6, "ROTONDA", "2:47", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(7, "STORIES VERDES", "2:56", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(8, "JACU'", "3:11", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(9, "DEL AVIÓN PA' TU APA", "3:20", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(10, "PETTY", "2:59", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(11, "WIKIWIKI", "3:03", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(12, "BIEN :(", "3:14", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(13, "NOCHES DE MÁS", "3:07", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a"),
                Cancion(14, "PUNTO NEMO", "2:55", "https://i.scdn.co/image/ab67616d0000b2738e9b340762e041b43408f16a")
            )

            val SAYONARA = arrayListOf(
                Cancion(1, "TE VI EN MIS PESADILLAS", "2:36", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(2, "KAWA", "2:25", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(3, "GATITAS SANDUNGUERAS VOL.1", "2:12", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(4, "PLN", "2:45", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(5, "FATAL FANTASSY", "2:29", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(6, "LENTITO", "3:24", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(7, "1000CANCIONES", "4:06", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(8, "BYAK", "3:36", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(9, "SIN PODERES", "3:27", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(10, "MAMI 100PRE SABE (INTERLUDE)", "2:18", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(11, "EN PR NO HACE FRÍO", "3:01", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(12, "A MI NOMBRE", "3:28", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(13, "QUIÉN TE QUIERE COMO EL NENE", "3:03", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(14, "MAJIN BUU", "2:57", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(15, "YOKO", "3:27", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(16, "QUIZÁS SÍ QUIZÁS NO", "3:23", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(17, "RAMONA FLOWERS", "3:01", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(18, "FUNERAL", "2:30", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(19, "GOLDEN GUN", "4:12", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b"),
                Cancion(20, "NO LLORES SI ME VOY", "2:40", "https://i.scdn.co/image/ab67616d0000b273af1e2e143561cf4df9941f5b")
            )

            val DO_NOT_DISTURB = arrayListOf(
                Cancion(1, "El intro", "2:11", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(2, "What’s Ur Vibe?", "1:56", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(3, "En el Ritz", "2:49", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(4, "WASSUP", "2:42", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(5, "Sexo de moteles", "3:22", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(6, "Dosis", "3:28", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(7, "Likey Likey", "2:25", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(8, "Ojalá", "3:18", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(9, "Sin pausa", "4:32", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(10, "Traviesa", "4:00", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(11, "Algo casual", "2:51", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(12, "Meiomi", "3:44", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(13, "Piki", "2:57", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(14, "Ni le cabe", "3:10", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(15, "Esa nena", "2:55", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c"),
                Cancion(16, "Plug (Type Shit)", "3:51", "https://i.scdn.co/image/ab67616d0000b2737fcd5648e2e2c477597e016c")
            )

            val TRANKI_TODO_PASA = arrayListOf(
                Cancion(1, "TOY PERDIO", "2:55", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(2, "Tarde", "2:00", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(3, "Gym Girl", "3:42", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(4, "Chiste JAJA", "3:07", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(5, "Picasso", "3:05", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(6, "1-0", "3:22", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(7, "Me Quedé Off", "3:22", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(8, "Tranki, Todo Pasa Interlude", "1:16", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(9, "Tus Labios - Remix", "3:15", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(10, "Aquí Pensando", "2:34", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(11, "Deli Gourmet", "2:56", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(12, "Te Lo Hundo", "2:19", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(13, "X Tu Culpa", "2:43", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a"),
                Cancion(14, "Casa De Mami", "3:46", "https://i.scdn.co/image/ab67616d0000b2738c6d5ab63909ce0b3709fd8a")
            )

            val SOME_SEXY_SONGS_4_U = arrayListOf(
                Cancion(1, "CN TOWER", "4:02", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(2, "MOTH BALLS", "3:33", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(3, "SOMETHING ABOUT YOU", "3:39", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(4, "CRYING IN CHANEL", "3:20", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(5, "SPIDER‑MAN SUPERMAN", "3:24", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(6, "DEEPER", "2:52", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(7, "SMALL TOWN FAME", "2:29", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(8, "PIMMIE'S DILEMMA", "1:58", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(9, "BRIAN STEEL", "1:51", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(10, "GIMME A HUG", "3:13", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(11, "RAINING IN HOUSTON", "4:05", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(12, "LASERS", "3:19", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(13, "MEET YOUR PADRE", "4:31", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(14, "NOKIA", "4:01", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(15, "DIE TRYING", "3:15", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(16, "SOMEBODY LOVES ME", "3:02", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(17, "CELIBACY", "3:55", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(18, "OMW", "3:53", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(19, "GLORIOUS", "3:25", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(20, "WHEN HE'S GONE", "3:30", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59"),
                Cancion(21, "GREEDY", "6:26", "https://i.scdn.co/image/ab67616d0000b273b5a28a256eae6dc0424fef59")
            )
        }

    }

}