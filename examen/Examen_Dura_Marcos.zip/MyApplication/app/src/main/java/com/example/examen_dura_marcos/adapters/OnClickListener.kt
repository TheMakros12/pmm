package com.example.examen_dura_marcos.adapters

import com.example.examen_dura_marcos.pojo.Evento

interface OnClickListener {
    fun onClick(evento: Evento)
}