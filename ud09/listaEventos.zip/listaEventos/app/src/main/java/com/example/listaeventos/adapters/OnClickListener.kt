package com.example.listaeventos.adapters

import com.example.listaeventos.entities.Evento

interface OnClickListener {

    fun onClick(evento: Evento)

}