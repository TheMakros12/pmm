package com.example.t5a1_dura_marcos.pojos

data class Comida(
    val nombre: String,
    val nacionalidad: String,
    val imagen: String,
    val url: String
)
