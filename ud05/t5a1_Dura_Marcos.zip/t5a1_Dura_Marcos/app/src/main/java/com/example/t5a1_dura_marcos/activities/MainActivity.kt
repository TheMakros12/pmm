package com.example.t5a1_dura_marcos.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.t5a1_dura_marcos.R
import com.example.t5a1_dura_marcos.adapters.ComidaAdapter
import com.example.t5a1_dura_marcos.adapters.OnClickListener
import com.example.t5a1_dura_marcos.databinding.ActivityMainBinding
import com.example.t5a1_dura_marcos.pojos.Comida

class MainActivity : AppCompatActivity(), OnClickListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var comidaAdapter: ComidaAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var itemDecoration: DividerItemDecoration

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        comidaAdapter = ComidaAdapter(getComidas(), this)
        linearLayoutManager = LinearLayoutManager(this)
        itemDecoration = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)

        binding.recylcerView.apply {
            layoutManager = linearLayoutManager
            adapter = comidaAdapter
            addItemDecoration(itemDecoration)
        }

    }

    override fun onClick(comida: Comida) {
        val intentWeb = Intent(this, WebActivity::class.java)
        intentWeb.putExtra("url", comida.url)
        startActivity(intentWeb)
    }

}

private fun getComidas(): MutableList<Comida> {
    val comidas = mutableListOf<Comida>()

    val pizza = Comida("Pizza", "Italia", "https://foodish-api.com/images/pizza/pizza1.jpg", "https://es.wikipedia.org/wiki/Pizza")
    val paella = Comida("Paella", "España", "https://foodish-api.com/images/rice/rice12.jpg", "https://es.wikipedia.org/wiki/Paella")
    val hamburguesa = Comida("Hamburguesa", "Estados Unidos", "https://foodish-api.com/images/burger/burger4.jpg", "https://es.wikipedia.org/wiki/Hamburguesa")
    val pasta = Comida("Pasta", "Italia", "https://foodish-api.com/images/pasta/pasta2.jpg", "https://es.wikipedia.org/wiki/Pasta")
    val kebab = Comida("Kebab", "Turquia", "https://foodish-api.com/images/dosa/dosa16.jpg", "https://es.wikipedia.org/wiki/Kebab")

    comidas.add(pizza)
    comidas.add(paella)
    comidas.add(hamburguesa)
    comidas.add(pasta)
    comidas.add(kebab)

    return comidas
}