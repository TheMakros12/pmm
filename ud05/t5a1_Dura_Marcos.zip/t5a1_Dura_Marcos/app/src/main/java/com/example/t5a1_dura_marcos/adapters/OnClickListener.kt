package com.example.t5a1_dura_marcos.adapters

import com.example.t5a1_dura_marcos.pojos.Comida

interface OnClickListener {
    fun onClick(comida: Comida)
}