package com.example.t5a1_dura_marcos.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.t5a1_dura_marcos.R
import com.example.t5a1_dura_marcos.databinding.ComidaItemBinding
import com.example.t5a1_dura_marcos.pojos.Comida

class ComidaAdapter(private val comidas: List<Comida>, private val listener: OnClickListener): RecyclerView.Adapter<ComidaAdapter.ViewHolder>() {

    private lateinit var context: Context

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        context = parent.context
        val view = LayoutInflater.from(context).inflate(R.layout.comida_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val comida = comidas.get(position)
        with(holder) {
            setListener(comida)
            binding.tvComida.text = comida.nombre
            binding.tvNacionalidad.text = comida.nacionalidad
            Glide.with(context)
                .load(comida.imagen)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .circleCrop()
                .into(binding.imgComida)
        }
    }

    override fun getItemCount(): Int = comidas.size

    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val binding = ComidaItemBinding.bind(view)
        fun setListener(comida: Comida) {
            binding.root.setOnClickListener {
                listener.onClick(comida )
            }
        }
    }

}