package com.example.reto2_dura_marcos.adapters

import com.example.reto2_dura_marcos.pojos.Personaje

interface OnClickListener {
    fun onClick(personaje: Personaje)
}