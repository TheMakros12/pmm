package com.example.reto2_dura_marcos.pojos

data class Personaje (
    val nombre: String
)