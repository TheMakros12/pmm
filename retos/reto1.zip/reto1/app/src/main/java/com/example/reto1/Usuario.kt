package com.example.reto1

data class Usuario(var nombre:String, var paaswd: String) {

}